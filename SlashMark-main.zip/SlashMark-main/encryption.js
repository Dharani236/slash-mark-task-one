'use strict';

const crypto = require('crypto');

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 16;
const SALT_LENGTH = 32;
const KEY_LENGTH = 32;
const ITERATIONS = 100000;

function deriveKey(password, salt) {
    return crypto.pbkdf2Sync(password, salt, ITERATIONS, KEY_LENGTH, 'sha512');
}

function encrypt(text, password) {
    if (!text) throw new Error('Text to encrypt is required');
    if (!password) throw new Error('Password is required');

    const salt = crypto.randomBytes(SALT_LENGTH);
    const iv = crypto.randomBytes(IV_LENGTH);
    const key = deriveKey(password, salt);

    const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');

    const authTag = cipher.getAuthTag();

    return [
        salt.toString('hex'),
        iv.toString('hex'),
        authTag.toString('hex'),
        encrypted
    ].join(':');
}

function decrypt(encryptedData, password) {
    if (!encryptedData) throw new Error('Encrypted data is required');
    if (!password) throw new Error('Password is required');

    const parts = encryptedData.split(':');
    if (parts.length !== 4) throw new Error('Invalid format');

    const salt = Buffer.from(parts[0], 'hex');
    const iv = Buffer.from(parts[1], 'hex');
    const authTag = Buffer.from(parts[2], 'hex');
    const encrypted = parts[3];

    const key = deriveKey(password, salt);
    const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
    decipher.setAuthTag(authTag);

    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');

    return decrypted;
}

// Demo if run directly
if (require.main === module) {
    const password = 'my-secret-password';
    const text = 'Hello, World!';

    console.log('=== Text Encryption Demo ===\n');
    
    const enc1 = encrypt(text, password);
    const enc2 = encrypt(text, password);
    
    console.log('Original:', text);
    console.log('Encrypt 1:', enc1);
    console.log('Encrypt 2:', enc2);
    console.log('Unique outputs?', enc1 !== enc2 ? 'YES' : 'NO');
    
    console.log('\nDecrypted 1:', decrypt(enc1, password));
    console.log('Decrypted 2:', decrypt(enc2, password));
}

module.exports = { encrypt, decrypt };