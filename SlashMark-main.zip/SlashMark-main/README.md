# Text Encryption Using Cryptographic Algorithms

## Description
A secure text encryption/decryption application using AES-256-GCM with random salt and IV to ensure unique outputs for identical inputs.

## Features
- AES-256-GCM authenticated encryption
- Random salt generation for key derivation
- Random IV for semantic security
- PBKDF2 key derivation (100,000 iterations)
- Unique ciphertext for every encryption

## Tech Stack
- Node.js
- Crypto module (built-in)

## How to Run
```bash
npm start